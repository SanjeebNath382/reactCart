const Items= [
    {name:"pen",id:1,price:10,company:"xyz",category:"stationery"},
     {name:"pencil",id:2,price:4,company:"abc",category:"stationery"},
     {name:"rubber",id:3,price:2,company:"abc",category:"stationery"},
     {name:"chart paper",id:4,price:5,company:"uio",category:"stationery"},
     {name:"water color",id:5,price:50,company:"cvb",category:"stationery"},
     {name:"Redmi Note 8 Pro",id:6,price:14999,company:"Xiaomi",category:"electronics"},
     {name:"Redmi Note 9 Pro",id:7,price:14999,company:"Xiaomi",category:"electronics"},
     {name:"Realme 5 Pro",id:8,price:15999,company:"Realme",category:"electronics"},
     {name:"Redmi Note 5 Pro",id:9,price:10999,company:"Xiaomi",category:"electronics"},
     {name:"Poco F-1",id:10,price:14999,company:"Xiaomi",category:"electronics"},
     {name:"Men's T-Shirt 102345",id:11,price:399,company:"Tommy HilFiger",category:"Fashion"},
     {name:"Men's T-Shirt 102346",id:12,price:599,company:"Tommy HilFiger",category:"Fashion"},
     {name:"Men's Summer T-Shirt",id:11,price:499,company:"FOXX",category:"Fashion"},
     {name:"Men's Polo T-Shirt",id:11,price:299,company:"Status Quo",category:"Fashion"},
  

     


]
export default Items;