import React, { useState,Component } from 'react'
import {connect} from 'react-redux'
import {AddToCart} from '../store/actions/actions'
import image from '..//static/girl-holds-fashion-shopping-bag-beauty_1150-13673.jpg'
import {Link} from 'react-router-dom'
import Data from '../Data'


 
 class ShoppingItems1 extends Component {
     state={
         id:0,
         name:"",
         price:0
     }
     onClickHand=(id,name,price)=>{
        this.props.AddToCart(id,name,price)

     }
     datafetch=()=>{
         Data.map(item=>{
             this.setState({
                 id:item.id,
                 name: item.name,
                 price: item.price

             })
         })
         console.log("data aayega")
     }
     componentDidMount() {
         this.datafetch();
     }
    render() {
        return (
            <>
            <Link to={'/cart'} className="btn btn-success">My Cart</Link>
   
   {
       Data.map(item=>{
           
                  
   
           return(
                <div className="containerFluid" id={item.id}>
              
   
          <div className="card d-flex" style={{width: "18rem",flexFlow:"wrap"}}>
       <img src={image} className="card-img-top" alt="Photo of a girl"></img>
    
        <div className="card-body">
       <h3 className="card-title" >{item.name}</h3>
       <h4 className="card-title">Price:{item.price}</h4>
       <h6 className="card-title">Company:{item.company}</h6>
       <button className="btn btn-primary" onClick={()=>{this.onClickHand(item.id,item.name,item.price)}}>Add To cart </button>
    
   </div>
   </div>
   
   </div> 
           )
       })
   }
   
                
            </>
        )
    }
}


const mapStateToProps = state => {
    return {
        addedItems:state.addedItems,
    total:state.total,
    toatalItems:state.totalItems,
    }
}

const mapDispatchToProps= dispatch =>{
    return{
        AddToCart: (id,name,price) => dispatch(AddToCart(id,name,price))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ShoppingItems1)



