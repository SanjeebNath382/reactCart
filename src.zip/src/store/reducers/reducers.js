import * as actTypes from "../actions/actionTypes"

const initValues = {
    addedItems: [],
    total: 0,
    totalItems: 0
}

 const AddToCart=(state,action)=>{
    return{
        ...state,
        addedItems: [...state.addedItems,action.addedItem],
        total: state.total+action.addedItem.price,
        totalItems: state.totalItems+1

    }
}

const DelCartItem=(state,action)=>{
    let upCart=[]; let newTotal=0;
    state.addedItems.map(item=>{
        if(item.id!==action.id)  {upCart.push(item)
            newTotal+=item.price
        }
    })
    return{
        ...state,
        addedItems:upCart,
        total: newTotal,
        totalItems: state.totalItems-1

    }
}

 const CartReducer = (state = initValues, action) => {
    switch (action.type) {
        case actTypes.ADD_TO_CART:
            return AddToCart(state,action)
        case actTypes.DEL_CART_ITEM:
            return DelCartItem(state,action)
        default:
            return state
    }
}

export default CartReducer;