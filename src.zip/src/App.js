import React from 'react';
import logo from './logo.svg';
import {BrowserRouter,Route,Link} from 'react-router-dom'
import Mycart from './containers/MyCart'
import './App.css';
import ShoppingItems from './containers/ShoppingItems'
import ShoppingList from './containers/ShoppingList'
import Data from './Data'

function App() {
  let k=1;
  return (
    <BrowserRouter>
    <Route exact path='/cart' component={Mycart} onClick={k=0}/ >
    <Route exact path='/' component={ShoppingItems} onClick={k=0}/ >
   
    
   
    
    
     {/* {
       
        Data.map(item=> {
          return <ShoppingItems item={item}/>
        })
       }  */}
       
        
       
    </BrowserRouter>
  );
}

export default App;
